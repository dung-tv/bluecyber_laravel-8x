

<?php $__env->startSection('content'); ?>
<h2>You have an error in the request</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bluecyber\task2\resources\views/errors/404.blade.php ENDPATH**/ ?>