<footer id="sticky-footer" class="py-4 bg-dark text-white-50 container">
    <div class="container text-center">
        <small>Copyright &copy; Your Website</small>
    </div>
</footer><?php /**PATH D:\xampp\htdocs\bluecyber\task2\resources\views/footer.blade.php ENDPATH**/ ?>