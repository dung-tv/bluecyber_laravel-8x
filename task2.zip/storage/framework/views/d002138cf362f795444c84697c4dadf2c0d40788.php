

<?php $__env->startSection('content'); ?>
<h2>Bạn chưa được cấp quyền vào trang này</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bluecyber\task2\resources\views/errors/401.blade.php ENDPATH**/ ?>