@extends('master')

@section('content')
<h2>Bạn chưa được cấp quyền vào trang này</h2>
@endsection