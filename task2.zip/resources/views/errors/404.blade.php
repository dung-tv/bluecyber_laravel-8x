@extends('master')

@section('content')
<h2>You have an error in the request</h2>
@endsection